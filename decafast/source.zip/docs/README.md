
Decaf Compiler Specifications
===================
Jiaqi Li (301295755) <br> Jingmin Zhu (301295748)

-------------------

###Description
* This is a parser program for the Decaf programming language.
 A parser is to provide an abstract syntax tree for valid Decaf programs.
 To see the detailed rules in the implementation, please see the source code.  

###Reference
* The rules for Decaf Language is based on the specifications by Anoop Sarker. 
The code is implemented by Jiaqi Li and Jingmin Zhu with collaboration on different parts of the grammar.
Note that the lexical analyzer is modified for the parser. And all the rules in the specifications are matched. 