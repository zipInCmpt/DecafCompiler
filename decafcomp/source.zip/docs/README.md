#Decaf Compiler

* Jiaqi Li (301295755)
* Jingmin Zhu (301295748)

-------------------

###Description
* This is a compiler for the Decaf programming language.
  The compiler now deals with all situations in HW4: global variables, zero initialization, while loops, for loops, if-else statements, short circuit, semantic checking and semantic error reporting. And therefore, it is supposed to be fully featured.

###Reference
* The rules for Decaf Language is based on the specifications by Anoop Sarker. 
The code is implemented by Jiaqi Li and Jingmin Zhu with collaboration on different parts of the assignment requirements.
* The code is based on the 3 previous assignments we have built on our own.

###New Test Case
* Please find in the newTestcase folder the test cases created on our own.